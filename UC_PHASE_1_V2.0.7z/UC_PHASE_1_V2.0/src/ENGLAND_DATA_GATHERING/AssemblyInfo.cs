using System;
using System.Reflection;
using System.Runtime.Versioning;
using System.Runtime.InteropServices;

using Rhino.PlugIns;

[assembly: PlugInDescription(DescriptionType.Organization, "Grimshaw")]
[assembly: PlugInDescription(DescriptionType.Email, "jorge.sainzdeaja@grimshaw.global")]
[assembly: PlugInDescription(DescriptionType.Phone, "")]
[assembly: PlugInDescription(DescriptionType.Address, "")]
[assembly: PlugInDescription(DescriptionType.Country, "United Kingdom")]
[assembly: PlugInDescription(DescriptionType.WebSite, "")]
[assembly: PlugInDescription(DescriptionType.UpdateUrl, "")]
[assembly: PlugInDescription(DescriptionType.Icon, "ENGLAND_DATA_GATHERING.Resources.projectIcon.ico")]

[assembly: AssemblyTitle("ENGLAND_DATA_GATHERING")]
[assembly: AssemblyDescription("GRIMSHAW Urban Computation Geospatial Data gathering for Urban Design Projects")]
[assembly: AssemblyCompany("Grimshaw")]
[assembly: AssemblyProduct("ENGLAND_DATA_GATHERING")]
[assembly: AssemblyCopyright("Copyright © 2025 GRIMSHAW Architects")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("6b598ad6-be18-424a-b4c8-2a8e6b3f79c1")]
[assembly: AssemblyVersion("0.3.30790.9334")]
[assembly: AssemblyFileVersion("0.3.30790.9334")]
[assembly: AssemblyInformationalVersion("0.3.30790.9334")]

[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
